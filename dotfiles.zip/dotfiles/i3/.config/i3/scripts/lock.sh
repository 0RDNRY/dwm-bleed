#!/bin/sh
i3lock-color -c 121212 --insidecolor=00000000 --ringcolor=4d4d4dff --keyhlcolor=ffffffff --ringvercolor=808080ff --ringwrongcolor=333333ff --line-uses-ring --verifcolor=ffffffff --wrongcolor=333333ff --timecolor=ffffffff --datecolor=808080ff --layoutcolor=808080ff --insidevercolor=00000000 --insidewrongcolor=00000000
