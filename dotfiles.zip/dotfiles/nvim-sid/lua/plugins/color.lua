return {
	"psliwka/termcolors.nvim",
}
