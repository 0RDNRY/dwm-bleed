return {
	"xiyaowong/transparent.nvim",
}
